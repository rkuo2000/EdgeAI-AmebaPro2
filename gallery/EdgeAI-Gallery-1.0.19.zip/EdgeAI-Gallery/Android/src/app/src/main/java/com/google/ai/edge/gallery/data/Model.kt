/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.data

import android.content.Context
import com.google.ai.edge.gallery.common.getModelStorageDir
import java.io.File
import kotlin.time.Duration
import kotlin.time.TimeMark
import kotlin.time.TimeSource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update

const val IMPORTS_DIR = "__imports"
private val NORMALIZE_NAME_REGEX = Regex("[^a-zA-Z0-9]")

data class PromptTemplate(val title: String, val description: String, val prompt: String)

/**
 * A model for a task (see [Task]).
 *
 * A task can have multiple models. For example, a task might be "LLM Chat", and it might have
 * models such as Gemma2, Gemma3, etc.
 */
data class Model(
  /**
   * The name of the model.
   *
   * This field is used to uniquely identify this model among all the tasks.
   *
   * IMPORTANT: it shouldn't contain "/" character.
   */
  val name: String,

  /**
   * The display name of the model, for display purpose.
   *
   * If this field is not set, the `name` field above will be used as the default display name.
   */
  val displayName: String = "",

  /**
   * (optional)
   *
   * A description or information about the model (Markdown supported).
   *
   * Displayed in the expanded model info card.
   */
  val info: String = "",

  /**
   * (optional)
   *
   * A list of configurable parameters for the model.
   *
   * If set, a gear icon appears on the right side of the model main screen's app bar. When
   * selected, a dialog pops up, allowing users to update the model's configurations.
   *
   * See [Config] for more details
   */
  var configs: List<Config> = listOf(),

  /**
   * (optional)
   *
   * The url to jump to when clicking "learn more" in model's info card.
   */
  val learnMoreUrl: String = "",

  /**
   * (optional)
   *
   * The task type ids that this model is best for.
   *
   * When set, the model's info card is pinned to the top of the model list when the corresponding
   * task is selected, expanded by default, and displays a "best overall" banner.
   *
   * Each task should only have one such model.
   */
  val bestForTaskIds: List<String> = listOf(),

  /**
   * (optional)
   *
   * The minimum device memory in GB to run the model.
   *
   * If set, a warning dialog will be shown when user trying to download the model or enter the
   * model screen.
   */
  val minDeviceMemoryInGb: Int? = null,

  /**
   * Download and storage metadata for the model files.
   *
   * Fill in this field if the model file needs to be downloaded from the internet. If you want to
   * manually manage model files without downloading them from the internet, set the
   * [ModelDownloadInfo.localRelativeDirPathOverride] field in `downloadInfo`.
   */
  val downloadInfo: ModelDownloadInfo = ModelDownloadInfo(),

  /** Platform and runtime backend configuration. */
  val backendSpec: BackendSpec = BackendSpec(),

  /** Model family hierarchy and variant configuration. */
  val hierarchy: ModelHierarchy = ModelHierarchy(),

  /** Whether the model is LLM or not. */
  val isLlm: Boolean = false,

  // The following fields are only used for built-in tasks. Can ignore if you are creating your own
  // custom tasks.
  //

  /** Whether to show the "run again" button in the UI. */
  val showRunAgainButton: Boolean = true,

  /** The prompt templates for the model (only for LLM). */
  val llmPromptTemplates: List<PromptTemplate> = listOf(),

  /** Whether the LLM model supports image input. */
  val llmSupportImage: Boolean = false,

  /** Whether the LLM model supports audio input. */
  val llmSupportAudio: Boolean = false,

  /** Whether the LLM model supports tiny garden. */
  val llmSupportTinyGarden: Boolean = false,

  /** Whether the LLM model supports mobile actions. */
  val llmSupportMobileActions: Boolean = false,

  /** The capabilities of the model. */
  val capabilities: List<ModelCapability> = listOf(),

  /** The max token for llm model. */
  val llmMaxToken: Int = 0,

  /** Compatible accelerators. */
  val accelerators: List<Accelerator> = listOf(),

  /** Accelerator for running vision encoder. */
  val visionAccelerator: Accelerator = Accelerator.GPU,

  /** A map of model capability to the task type ids that the model capability is allowed for. */
  val capabilityToTaskTypes: Map<ModelCapability, List<String>> = mapOf(),

  /** (optional) Strongly-typed metadata for the model. See [ModelMetadata] for more details. */
  val metadata: ModelMetadata = ModelMetadata(),

  // The following fields are managed by the app. Don't need to set manually.
  //
  var normalizedName: String = "",
  // TODO(jingjin): use a "queue" system to manage model init and cleanup.
  var cleanUpAfterInit: Boolean = false,
  var configValues: Map<String, Any> = mapOf(),
  var prevConfigValues: Map<String, Any> = mapOf(),
) {
  init {
    normalizedName = NORMALIZE_NAME_REGEX.replace(name, "_")
  }

  /** Indicates whether this model configuration represents a variant of a parent model. */
  val isVariant: Boolean
    get() = hierarchy.isVariant

  /** Indicates whether the runtime type is AICore. */
  val isAiCore: Boolean
    get() = backendSpec.isAiCore

  /** Indicates whether the runtime type is LiteRT-LM. */
  val isLiteRtLm: Boolean
    get() = backendSpec.isLiteRtLm

  sealed interface InitializationStatus {
    data object Idle : InitializationStatus

    data class Initializing(val startTimeMark: TimeMark) : InitializationStatus

    data class Initialized(val instance: Any?, val duration: Duration) : InitializationStatus

    data class Failed(val error: Throwable, val duration: Duration) : InitializationStatus
  }

  internal val _initStatusFlow = MutableStateFlow<InitializationStatus>(InitializationStatus.Idle)
  val initStatusFlow: StateFlow<InitializationStatus> = _initStatusFlow.asStateFlow()

  val initDuration: Duration?
    get() =
      when (val status = _initStatusFlow.value) {
        is InitializationStatus.Initialized -> status.duration
        is InitializationStatus.Failed -> status.duration
        else -> null
      }

  var instance: Any?
    get() = (_initStatusFlow.value as? InitializationStatus.Initialized)?.instance
    set(value) {
      if (value == null) {
        resetInitialization()
      } else {
        markInitialized(value)
      }
    }

  val initializing: Boolean
    get() = _initStatusFlow.value is InitializationStatus.Initializing

  fun preProcess() {
    val configValues: MutableMap<String, Any> = mutableMapOf()
    for (config in this.configs) {
      configValues[config.key.label] = config.defaultValue
    }
    this.configValues = configValues
  }

  fun getPath(context: Context, fileName: String = downloadInfo.downloadFileName): String {
    if (downloadInfo.imported) {
      return listOf(getModelStorageDir(context).absolutePath, IMPORTS_DIR, fileName)
        .joinToString(File.separator)
    }

    if (downloadInfo.localModelFilePathOverride.isNotEmpty()) {
      return downloadInfo.localModelFilePathOverride
    }

    if (downloadInfo.localRelativeDirPathOverride.isNotEmpty()) {
      return listOf(
          getModelStorageDir(context).absolutePath,
          downloadInfo.localRelativeDirPathOverride,
          fileName,
        )
        .joinToString(File.separator)
    }

    val activeFile = resolveActiveModelFile(context)
    val activeVersion = activeFile?.first ?: downloadInfo.version
    val targetFileName =
      if (fileName == downloadInfo.downloadFileName && activeFile != null) {
        activeFile.second
      } else {
        fileName
      }

    val baseDir =
      listOf(getModelStorageDir(context).absolutePath, normalizedName, activeVersion)
        .joinToString(File.separator)
    return if (
      downloadInfo.isZip &&
        downloadInfo.unzipDir.isNotEmpty() &&
        fileName == downloadInfo.downloadFileName
    ) {
      listOf(baseDir, downloadInfo.unzipDir).joinToString(File.separator)
    } else {
      listOf(baseDir, targetFileName).joinToString(File.separator)
    }
  }

  private fun resolveActiveModelFile(context: Context): Pair<String, String>? {
    val storageDir = getModelStorageDir(context)
    val latestDir = File(storageDir, "$normalizedName${File.separator}${downloadInfo.version}")
    if (latestDir.exists()) {
      return Pair(downloadInfo.version, downloadInfo.downloadFileName)
    }

    for (updatable in downloadInfo.updatableModelFiles) {
      if (updatable.commitHash.isEmpty()) continue
      val legacyDir = File(storageDir, "$normalizedName${File.separator}${updatable.commitHash}")
      if (legacyDir.exists()) {
        return Pair(updatable.commitHash, updatable.fileName)
      }
    }

    return null
  }

  fun getIntConfigValue(key: ConfigKey, defaultValue: Int = 0): Int {
    return getTypedConfigValue(key = key, valueType = ValueType.INT, defaultValue = defaultValue)
      as Int
  }

  fun getFloatConfigValue(key: ConfigKey, defaultValue: Float = 0.0f): Float {
    return getTypedConfigValue(key = key, valueType = ValueType.FLOAT, defaultValue = defaultValue)
      as Float
  }

  fun getBooleanConfigValue(key: ConfigKey, defaultValue: Boolean = false): Boolean {
    return getTypedConfigValue(
      key = key,
      valueType = ValueType.BOOLEAN,
      defaultValue = defaultValue,
    )
      as Boolean
  }

  fun getStringConfigValue(key: ConfigKey, defaultValue: String = ""): String {
    return getTypedConfigValue(key = key, valueType = ValueType.STRING, defaultValue = defaultValue)
      as String
  }

  private fun getTypedConfigValue(key: ConfigKey, valueType: ValueType, defaultValue: Any): Any {
    return convertValueToTargetType(
      value = configValues.getOrDefault(key.label, defaultValue),
      valueType = valueType,
    )
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Configs.

val EMPTY_MODEL: Model =
  Model(
    name = "empty",
    downloadInfo = ModelDownloadInfo(downloadFileName = "empty.tflite", url = "", sizeInBytes = 0L),
  )

val Model.supportModelBenchmark: Boolean
  get() =
    isLiteRtLm ||
      false

/** Marks the model as initialization started. */
fun Model.markInitializationStarted(timeSource: TimeSource = TimeSource.Monotonic) {
  this._initStatusFlow.update { Model.InitializationStatus.Initializing(timeSource.markNow()) }
}

/**
 * Marks the model as initialized.
 *
 * @param instance The initialized model instance.
 */
fun Model.markInitialized(instance: Any? = this.instance) {
  this._initStatusFlow.update { current ->
    when (current) {
      is Model.InitializationStatus.Initializing -> {
        val duration = current.startTimeMark.elapsedNow()
        Model.InitializationStatus.Initialized(instance = instance, duration = duration)
      }
      is Model.InitializationStatus.Initialized -> {
        val resolved = instance ?: current.instance
        Model.InitializationStatus.Initialized(instance = resolved, duration = current.duration)
      }
      else -> {
        Model.InitializationStatus.Initialized(instance = instance, duration = Duration.ZERO)
      }
    }
  }
}

/** Marks the model as initialization failed with the given [error]. */
fun Model.markInitializationFailed(error: Throwable) {
  this._initStatusFlow.update { current ->
    when (current) {
      is Model.InitializationStatus.Initializing -> {
        val duration = current.startTimeMark.elapsedNow()
        Model.InitializationStatus.Failed(error = error, duration = duration)
      }
      is Model.InitializationStatus.Initialized -> {
        Model.InitializationStatus.Failed(error = error, duration = current.duration)
      }
      is Model.InitializationStatus.Failed -> {
        Model.InitializationStatus.Failed(error = error, duration = current.duration)
      }
      else -> {
        Model.InitializationStatus.Failed(error = error, duration = Duration.ZERO)
      }
    }
  }
}

/** Marks the model as initialization failed with the given [errorMessage]. */
fun Model.markInitializationFailed(errorMessage: String) {
  markInitializationFailed(IllegalStateException(errorMessage))
}

/** Resets the model initialization. */
fun Model.resetInitialization() {
  this._initStatusFlow.update { Model.InitializationStatus.Idle }
}

/** Waits for the model initialization to finish. */
suspend fun Model.awaitInitialization() {
  val status = initStatusFlow.first { it !is Model.InitializationStatus.Initializing }
  if (status is Model.InitializationStatus.Failed) {
    throw status.error
  }
}
