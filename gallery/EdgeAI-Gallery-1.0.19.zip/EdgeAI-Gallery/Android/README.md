# Google AI Edge Gallery (Android)

### Local API audio input

The local `/v1/chat/completions` endpoint accepts one base64 audio clip with a text
prompt when the active model session supports audio:

```json
{"model":"YOUR_MODEL_ALIAS","messages":[{"role":"user","content":[
  {"type":"text","text":"Transcribe this audio"},
  {"type":"input_audio","input_audio":{"format":"mp3","data":"BASE64_FILE_BYTES"}}
]}]}
```

Use `format: "wav"`, `"mp3"`, or `"mp4"`. MP3 and MP4 are decoded on-device to
mono 16-bit PCM WAV; MP4 uses its first audio track and ignores video. Codec
availability depends on the Android device. Compressed clips are limited to
30 seconds of decoded samples, 8–48 kHz, and 1–8 channels (averaged to mono).
Decoding has a 30-second deadline. Invalid/unsupported media or missing audio
returns HTTP 400; excessive decoded duration returns 413. The existing 6 MiB
limit applies to the entire JSON request, including base64 and any image.
WAV input retains its existing mono 16-bit PCM, 8–48 kHz requirements.

Decoder instrumentation tests include generated MP3, AAC-in-MP4, and video-only
fixtures in `app/src/androidTest/assets/audio`. Run on a connected Android device
with `./gradlew :app:connectedDebugAndroidTest
-Pandroid.testInstrumentationRunnerArguments.class=com.google.ai.edge.gallery.api.ApiAudioDecoderTest`
(from `Android/src`, on one line).
