/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.agent

import com.google.ai.edge.gallery.common.metrics.MetricsTracker

/**
 * Encapsulates the runtime execution context and observability metadata for an agent turn.
 *
 * @property metadata Additional execution-scoped key-value configuration flags.
 * @property metricsTracker Optional telemetry tracker for the current execution turn.
 */
data class AgentExecutionContext(
  val metadata: Map<String, Any> = emptyMap(),
  val metricsTracker: MetricsTracker? = null,
)
