/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.ui.common

import android.content.Intent
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.TextAutoSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import com.google.ai.edge.gallery.R
import com.google.ai.edge.gallery.data.Model
import com.google.ai.edge.gallery.data.ModelAccessibility
import com.google.ai.edge.gallery.data.ModelDownloadStatusType
import com.google.ai.edge.gallery.data.Task
import com.google.ai.edge.gallery.huggingface.HuggingFaceApiClient
import com.google.ai.edge.gallery.ui.common.tos.GemmaTermsOfUseDialog
import com.google.ai.edge.gallery.ui.common.tos.TosViewModel
import com.google.ai.edge.gallery.ui.modelmanager.ModelManagerViewModel
import com.google.ai.edge.gallery.ui.modelmanager.TokenRequestResultType
import com.google.ai.edge.gallery.ui.modelmanager.TokenStatus
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

private const val TAG = "AGDownloadAndTryButton"
private const val SYSTEM_RESERVED_MEMORY_IN_BYTES = 3 * (1L shl 30)

private val MODEL_NAMES_TO_SHOW_GEMMA_LICENSES =
  setOf("Gemma-3n-E2B-it", "Gemma-3n-E4B-it", "Gemma3-1B-IT", "Gemma3-1B-IT NPU")

/**
 * Handles the "Download & Try it" button click, managing the model download process based on
 * various conditions.
 *
 * If the button is enabled and not currently checking the token, it initiates a coroutine to handle
 * the download logic.
 *
 * For models requiring download first, it specifically addresses HuggingFace URLs by first checking
 * if authentication is necessary. If no authentication is needed, the download starts directly.
 * Otherwise, it checks the current token status; if the token is invalid or expired, a token
 * exchange flow is initiated. If a valid token exists, it attempts to access the download URL. If
 * access is granted, the download begins; if not, a new token is requested.
 *
 * For non-HuggingFace URLs that need downloading, the download starts directly.
 *
 * If the model doesn't need to be downloaded first, the provided `onClicked` callback is executed.
 *
 * Additionally, for gated HuggingFace models, if accessing the model after token exchange results
 * in a forbidden error, a modal bottom sheet is displayed, prompting the user to acknowledge the
 * user agreement by opening it in a custom tab. Upon closing the tab, the download process is
 * retried.
 *
 * The composable also manages UI states for indicating token checking and displaying the agreement
 * acknowledgement sheet, and it handles requesting notification permissions before initiating the
 * actual download.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadAndTryButton(
  task: Task?,
  model: Model,
  enabled: Boolean,
  downloadStatus: ModelDownloadStatusType?,
  downloadProgress: Float,
  modelManagerViewModel: ModelManagerViewModel,
  onClicked: () -> Unit,
  modifier: Modifier = Modifier,
  tosViewModel: TosViewModel = hiltViewModel(),
  modifierWhenExpanded: Modifier = Modifier,
  compact: Boolean = false,
  canShowTryIt: Boolean = true,
  downloadButtonBackgroundColor: Color = MaterialTheme.colorScheme.surfaceContainer,
  mainDispatcher: CoroutineDispatcher = Dispatchers.Main,
) {
  val scope = rememberCoroutineScope()
  val context = LocalContext.current
  var checkingToken by remember { mutableStateOf(false) }
  var showAgreementAckSheet by remember { mutableStateOf(false) }
  var showErrorDialog by remember { mutableStateOf(false) }
  var showMemoryWarning by remember { mutableStateOf(false) }
  var showGemmaTermsOfUseDialog by remember { mutableStateOf(false) }
  var downloadStarted by remember { mutableStateOf(false) }
  val sheetState = rememberModalBottomSheetState()

  val needToDownloadFirst =
    (downloadStatus == ModelDownloadStatusType.NOT_DOWNLOADED ||
      downloadStatus == ModelDownloadStatusType.FAILED) &&
      model.downloadInfo.localRelativeDirPathOverride.isEmpty() &&
      !model.isAiCore
  val inProgress = downloadStatus == ModelDownloadStatusType.IN_PROGRESS
  val downloadSucceeded = downloadStatus == ModelDownloadStatusType.SUCCEEDED
  val isPartiallyDownloaded = downloadStatus == ModelDownloadStatusType.PARTIALLY_DOWNLOADED
  val showDownloadProgress =
    !downloadSucceeded && (downloadStarted || checkingToken || inProgress || isPartiallyDownloaded)

  val view = LocalView.current
  val completedCd = stringResource(R.string.cd_download_completed)
  LaunchedEffect(downloadSucceeded) {
    if (downloadSucceeded && downloadStarted) {
      downloadStarted = false
      view.announceForAccessibility(completedCd)
    }
  }

  // A launcher for requesting notification permission.
  val permissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
      modelManagerViewModel.downloadModel(task = task, model = model)
    }

  // Function to kick off download.
  val startDownload: (accessToken: String?) -> Unit = { accessToken ->
    downloadStarted = true
    checkingToken = false
    model.downloadInfo.accessToken = accessToken
    checkNotificationPermissionAndStartDownload(
      context = context,
      launcher = permissionLauncher,
      modelManagerViewModel = modelManagerViewModel,
      task = task,
      model = model,
    )
  }

  // Function to fetch the remote model accessibility.
  fun processModelAccessibility(token: String? = null, onNeedsTokenExchange: (() -> Unit)? = null) {
    val accessToken = token?.takeIf { it.isNotEmpty() }
    scope.launch(mainDispatcher) {
      checkingToken = true
      val accessibility =
        modelManagerViewModel.checkModelAccessibility(model = model, accessToken = accessToken)

      when (accessibility) {
        ModelAccessibility.ACCESSIBLE -> {
          Log.d(TAG, "Model '${model.name}' is accessible. Starting download...")
          startDownload(accessToken)
        }
        ModelAccessibility.GATED -> {
          Log.d(
            TAG,
            "Model '${model.name}' is gated (403). Displaying license acknowledgment sheet.",
          )
          checkingToken = false
          downloadStarted = false
          showAgreementAckSheet = true
        }
        ModelAccessibility.NEEDS_TOKEN_EXCHANGE -> {
          Log.d(TAG, "Model '${model.name}' requires a new token. Initiating OAuth exchange...")
          checkingToken = false
          downloadStarted = false
          onNeedsTokenExchange?.invoke()
        }
        ModelAccessibility.ERROR -> {
          Log.e(TAG, "Unknown network error when accessing model '${model.name}'")
          checkingToken = false
          downloadStarted = false
          showErrorDialog = true
        }
      }
    }
  }

  // A launcher for handling the authentication flow.
  // It processes the result of the authentication activity and then checks if a user agreement
  // acknowledgement is needed before proceeding with the model download.
  val authResultLauncher =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
      modelManagerViewModel.handleAuthResult(
        result,
        onTokenRequested = { tokenRequestResult ->
          when (tokenRequestResult.status) {
            TokenRequestResultType.SUCCEEDED -> {
              Log.d(TAG, "Token request succeeded. Checking model accessibility.")
              val token = modelManagerViewModel.curAccessToken
              processModelAccessibility(token)
            }

            TokenRequestResultType.FAILED -> {
              Log.d(
                TAG,
                "Token request done. Error message: ${tokenRequestResult.errorMessage ?: ""}",
              )
              checkingToken = false
              downloadStarted = false
            }

            TokenRequestResultType.USER_CANCELLED -> {
              Log.d(TAG, "User cancelled. Do nothing")
              checkingToken = false
              downloadStarted = false
            }
          }
        },
      )
    }

  // Function to kick off the authentication and token exchange flow.
  val startTokenExchange = {
    val authRequest = modelManagerViewModel.getAuthorizationRequest()
    val authIntent = modelManagerViewModel.authService.getAuthorizationRequestIntent(authRequest)
    authResultLauncher.launch(authIntent)
  }

  // A launcher for opening the custom tabs intent for requesting user agreement ack.
  // Once the tab is closed, re-probe model accessibility before starting download.
  val agreementAckLauncher: ActivityResultLauncher<Intent> =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.StartActivityForResult()
    ) { _ ->
      Log.d(TAG, "User closes the browser tab. Re-probe model accessibility before downloading.")
      val token =
        modelManagerViewModel.curAccessToken.takeIf { it.isNotEmpty() }
          ?: modelManagerViewModel.getTokenStatusAndData().data?.accessToken
      processModelAccessibility(token, onNeedsTokenExchange = startTokenExchange)
    }

  // Handles the initial check and potential authentication flow before downloading the model.
  // If the model is from Hugging Face, verifies accessibility asynchronously and initiates
  // token exchange or downloads directly.
  val handleClickButton = {
    if (needToDownloadFirst) {
      // For HuggingFace urls
      if (HuggingFaceApiClient.isHuggingFaceUrl(model.downloadInfo.url)) {
        Log.d(
          TAG,
          "Model '${model.name}' is from HuggingFace. Checking token status and model accessibility.",
        )
        val tokenStatusAndData = modelManagerViewModel.getTokenStatusAndData()
        val storedToken =
          if (tokenStatusAndData.status == TokenStatus.NOT_EXPIRED) {
            tokenStatusAndData.data?.accessToken
          } else {
            null
          }

        processModelAccessibility(storedToken, onNeedsTokenExchange = startTokenExchange)
      }
      // For other urls, just download the model.
      else {
        Log.d(TAG, "Model '${model.name}' is not from huggingface. Start downloading the model...")
        startDownload(null)
      }
    }
    // No need to download. Directly open the model.
    else {
      onClicked()
    }
  }

  val checkMemoryAndClickDownloadButton = {
    if (isMemoryLow(context = context, model = model)) {
      showMemoryWarning = true
    } else {
      handleClickButton()
    }
  }

  if (!showDownloadProgress) {
    var buttonModifier: Modifier = modifier.height(42.dp)
    if (!compact) {
      buttonModifier = buttonModifier.then(modifierWhenExpanded)
    }
    Button(
      modifier = buttonModifier,
      colors =
        ButtonDefaults.buttonColors(
          containerColor =
            if (
              (!downloadSucceeded || !canShowTryIt) &&
                model.downloadInfo.localRelativeDirPathOverride.isEmpty()
            ) {
              downloadButtonBackgroundColor
            } else if (task != null) {
              getTaskBgGradientColors(task = task)[1]
            } else {
              MaterialTheme.colorScheme.primary
            }
        ),
      contentPadding = PaddingValues(horizontal = 12.dp),
      onClick = {
        if (!enabled || checkingToken) {
          return@Button
        }

        // Check TOS before downloading.
        if (
          model.downloadInfo.url.startsWith("https://dl.google.com/google-ai-edge-gallery/") &&
            MODEL_NAMES_TO_SHOW_GEMMA_LICENSES.contains(model.name) &&
            !tosViewModel.getIsGemmaTermsOfUseAccepted()
        ) {
          showGemmaTermsOfUseDialog = true
        } else {
          checkMemoryAndClickDownloadButton()
        }
      },
    ) {
      val textColor =
        if (!enabled) {
          // Define the color for disabled button.
          MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
        } else if (
          !downloadSucceeded && model.downloadInfo.localRelativeDirPathOverride.isEmpty()
        ) {
          MaterialTheme.colorScheme.onSurface
        } else if (task != null) {
          Color.White
        } else {
          MaterialTheme.colorScheme.onPrimary
        }
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(
          if (needToDownloadFirst) {
            Icons.Outlined.FileDownload
          } else {
            Icons.AutoMirrored.Rounded.ArrowForward
          },
          contentDescription = null,
          tint = textColor,
        )

        if (!compact) {
          if (needToDownloadFirst) {
            Text(
              stringResource(R.string.download),
              color = textColor,
              style = MaterialTheme.typography.titleMedium,
            )
          } else if (canShowTryIt) {
            Text(
              stringResource(R.string.try_it),
              color = textColor,
              style = MaterialTheme.typography.titleMedium,
              maxLines = 1,
              autoSize =
                TextAutoSize.StepBased(minFontSize = 8.sp, maxFontSize = 16.sp, stepSize = 1.sp),
            )
          }
        }
      }
    }
  }
  // Download progress.
  else {
    val animatedProgress = remember { Animatable(0f) }

    var downloadProgressModifier: Modifier = modifier
    if (!compact) {
      downloadProgressModifier = downloadProgressModifier.fillMaxWidth()
    }
    downloadProgressModifier =
      downloadProgressModifier
        .clip(CircleShape)
        .background(MaterialTheme.colorScheme.surfaceContainer)
        .padding(horizontal = 8.dp)
        .height(42.dp)
    Row(modifier = downloadProgressModifier, verticalAlignment = Alignment.CenterVertically) {
      if (checkingToken) {
        Text(
          stringResource(R.string.checking_access),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurface,
          textAlign = TextAlign.Center,
          modifier = if (!compact) Modifier.fillMaxWidth() else Modifier.padding(horizontal = 4.dp),
        )
      } else {
        val progressPercent = (downloadProgress * 100).toInt()
        val progressCd = stringResource(R.string.cd_download_progress, progressPercent)
        val textSemanticsModifier =
          if (compact) {
            Modifier.semantics {
                progressBarRangeInfo = ProgressBarRangeInfo(downloadProgress, 0f..1f)
                contentDescription = progressCd
              }
              .padding(start = 12.dp)
              .width(32.dp)
          } else {
            Modifier.clearAndSetSemantics {}.padding(start = 12.dp).width(44.dp)
          }
        Text(
          "$progressPercent%",
          style =
            MaterialTheme.typography.bodyMedium.copy(
              // This stops numbers from "jumping around" when being updated.
              fontFeatureSettings = "tnum"
            ),
          color = MaterialTheme.colorScheme.onSurface,
          modifier = textSemanticsModifier,
        )
        if (!compact) {
          val color =
            if (task != null) getTaskBgGradientColors(task = task)[1]
            else MaterialTheme.colorScheme.primary
          LinearProgressIndicator(
            modifier =
              Modifier.weight(1f).padding(horizontal = 4.dp).semantics {
                contentDescription = progressCd
              },
            progress = { animatedProgress.value },
            color = color,
            trackColor = MaterialTheme.colorScheme.surfaceContainerHighest,
          )
        }
        val cbStop = stringResource(R.string.cd_stop_icon)
        IconButton(
          onClick = {
            downloadStarted = false
            modelManagerViewModel.cancelDownloadModel(model = model)
          },
          colors =
            IconButtonDefaults.iconButtonColors(
              containerColor = MaterialTheme.colorScheme.surfaceContainer
            ),
          modifier = Modifier.semantics { contentDescription = cbStop },
        ) {
          Icon(
            Icons.Outlined.Close,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurface,
          )
        }
      }
    }
    LaunchedEffect(downloadProgress) {
      animatedProgress.animateTo(downloadProgress, animationSpec = tween(150))
    }
  }

  // A ModalBottomSheet composable that displays information about the user agreement
  // for a gated model and provides a button to open the agreement in a custom tab.
  // Upon clicking the button, it constructs the agreement URL, launches it using a
  // custom tab, and then dismisses the bottom sheet.
  if (showAgreementAckSheet) {
    ModalBottomSheet(
      onDismissRequest = {
        showAgreementAckSheet = false
        checkingToken = false
        downloadStarted = false
      },
      sheetState = sheetState,
      modifier = Modifier.wrapContentHeight(),
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 16.dp),
      ) {
        Text(
          stringResource(R.string.acknowledge_user_agreement),
          style = MaterialTheme.typography.titleLarge,
        )
        Text(
          stringResource(R.string.gated_model_agreement_help),
          style = MaterialTheme.typography.bodyMedium,
          modifier = Modifier.padding(vertical = 16.dp),
        )
        Button(
          onClick = {
            // Get agreement url from model url.
            val index = model.downloadInfo.url.indexOf("/resolve/")
            // Show it in a tab.
            if (index >= 0) {
              val agreementUrl = model.downloadInfo.url.substring(0, index)

              val customTabsIntent = CustomTabsIntent.Builder().build()
              customTabsIntent.intent.setData(agreementUrl.toUri())
              agreementAckLauncher.launch(customTabsIntent.intent)
            }
            // Dismiss the sheet.
            showAgreementAckSheet = false
            checkingToken = false
            downloadStarted = false
          }
        ) {
          Text(stringResource(R.string.open_user_agreement))
        }
      }
    }
  }

  if (showErrorDialog) {
    AlertDialog(
      icon = {
        Icon(
          Icons.Rounded.Error,
          contentDescription = stringResource(R.string.cd_error),
          tint = MaterialTheme.colorScheme.error,
        )
      },
      title = { Text(stringResource(R.string.error_unknown_network)) },
      text = { Text(stringResource(R.string.error_check_internet)) },
      onDismissRequest = { showErrorDialog = false },
      confirmButton = {
        TextButton(onClick = { showErrorDialog = false }) { Text(stringResource(R.string.close)) }
      },
    )
  }

  if (showMemoryWarning) {
    MemoryWarningAlert(
      onProceeded = {
        handleClickButton()
        showMemoryWarning = false
      },
      onDismissed = { showMemoryWarning = false },
    )
  }

  if (showGemmaTermsOfUseDialog) {
    GemmaTermsOfUseDialog(
      onTosAccepted = {
        showGemmaTermsOfUseDialog = false
        tosViewModel.acceptGemmaTermsOfUse()
        checkMemoryAndClickDownloadButton()
      },
      onCancel = { showGemmaTermsOfUseDialog = false },
    )
  }
}
