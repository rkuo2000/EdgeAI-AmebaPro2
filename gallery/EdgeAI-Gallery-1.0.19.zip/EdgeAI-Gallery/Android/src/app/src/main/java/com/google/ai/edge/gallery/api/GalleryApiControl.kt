/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.api

import android.content.Context
import android.os.Build
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.gallery.data.Model
import com.google.ai.edge.gallery.data.markInitializationFailed
import com.google.ai.edge.gallery.ui.llmchat.LlmModelInstance
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

@Composable
internal fun GalleryApiControl(model: Model, busy: Boolean, supportImage: Boolean = false, supportAudio: Boolean = false, chatHistory: () -> List<Message> = { emptyList() }) {
  var show by remember { mutableStateOf(false) }
  var permissionDenied by remember { mutableStateOf(false) }
  val initialization by model.initStatusFlow.collectAsState()
  val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
    permissionDenied = !it
    show = it
  }
  val supported = (initialization as? Model.InitializationStatus.Initialized)?.instance is LlmModelInstance
  Column(Modifier.statusBarsPadding()) {
    TextButton(enabled = supported && !busy, onClick = {
      if (Build.VERSION.SDK_INT >= 37) permission.launch("android.permission.ACCESS_LOCAL_NETWORK")
      else show = true
    }) { Text("Text / image / audio API") }
    if (permissionDenied) Text("Allow local network access to receive API requests.")
  }
  if (show) ApiDialog(model, supportImage, supportAudio, chatHistory) { show = false }
}

@Composable
private fun ApiDialog(model: Model, supportImage: Boolean, supportAudio: Boolean, chatHistory: () -> List<Message>, onClose: () -> Unit) {
  val context = LocalContext.current.applicationContext
  val token = remember(context, model.name) {
    val preferences = context.getSharedPreferences("gallery_api_keys", Context.MODE_PRIVATE)
    preferences.getString(model.name, null) ?: UUID.randomUUID().toString().replace("-", "").also {
      preferences.edit().putString(model.name, it).apply()
    }
  }
  val alias = remember(model.name) {
    when {
      model.name.startsWith("Gemma-4-", true) -> if (model.name.contains("E4B", true)) "gemma4:e4b" else "gemma4:e2b"
      else -> model.name
    }
  }
  var status by remember { mutableStateOf("Starting…") }
  var addresses by remember { mutableStateOf("") }
  var stop by remember { mutableStateOf(false) }
  val owner = LocalLifecycleOwner.current
  DisposableEffect(owner) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_STOP) stop = true
    }
    owner.lifecycle.addObserver(observer)
    onDispose { owner.lifecycle.removeObserver(observer) }
  }
  LaunchedEffect(Unit) {
    val server = GalleryApiServer(model.instance as LlmModelInstance, model.name, alias, token, supportImage, supportAudio, chatHistory()) {
      status = it
    }
    try {
      withContext(Dispatchers.IO) {
        addresses = NetworkInterface.getNetworkInterfaces().toList()
          .flatMap { it.inetAddresses.toList() }
          .filter { it is Inet4Address && !it.isLoopbackAddress }
          .joinToString("\n") { "http://${it.hostAddress}:11434/v1/chat/completions" }
        server.start()
      }
      status = "Ready. Keep this screen open."
      snapshotFlow { stop }.first { it }
    } catch (e: kotlinx.coroutines.CancellationException) {
      throw e
    } catch (e: Exception) {
      status = "Cannot start API: ${e.message}"
      snapshotFlow { stop }.first { it }
    } finally {
      withContext(NonCancellable + Dispatchers.IO) {
        try {
          server.close()
        } catch (e: Exception) {
          Log.e("GalleryApiServer", "Failed to restore chat after API shutdown", e)
          // Do not leave the UI pointing at the session released when API mode started.
          val instance = model.instance as? LlmModelInstance
          runCatching { instance?.engine?.close() }
          model.markInitializationFailed(e)
        }
      }
    }
    onClose()
  }
  AlertDialog(
    onDismissRequest = { stop = true },
    title = { Text("AI Chat API") },
    text = {
      SelectionContainer {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(4.dp)) {
          Text("$addresses\n\nModel: $alias\nAPI key: $token\n\nThis key is saved for this model and reused when you reopen the API. Use this API key in your client. Supports text${if (supportImage) ", JPEG/PNG images" else ""}${if (supportAudio) ", WAV/MP3/MP4 audio" else ""} in this session. Keep this screen open on a trusted Wi-Fi network.\n\n$status")
        }
      }
    },
    confirmButton = {
      TextButton(enabled = !stop, onClick = { stop = true }) {
        Text(if (stop) "Stopping…" else "Stop API")
      }
    },
  )
}
