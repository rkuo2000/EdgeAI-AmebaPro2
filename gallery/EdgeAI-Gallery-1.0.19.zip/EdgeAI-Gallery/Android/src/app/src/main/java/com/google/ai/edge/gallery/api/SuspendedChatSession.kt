package com.google.ai.edge.gallery.api

/** Transfers the engine's single session slot to API mode and back. Used on IO threads. */
internal class SuspendedChatSession(
  private val release: () -> Unit,
  private val restore: () -> Unit,
) {
  private var suspended = false

  fun suspend() {
    check(!suspended) { "Chat session is already suspended" }
    release()
    suspended = true
  }

  fun restore() {
    if (!suspended) return
    restore.invoke()
    suspended = false
  }
}
