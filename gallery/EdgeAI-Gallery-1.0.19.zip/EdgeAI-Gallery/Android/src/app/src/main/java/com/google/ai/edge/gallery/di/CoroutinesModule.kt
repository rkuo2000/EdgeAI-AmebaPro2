/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Qualifier
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers

@Qualifier @Retention(AnnotationRetention.BINARY) annotation class IoDispatcher

@Qualifier @Retention(AnnotationRetention.BINARY) annotation class DefaultDispatcher

@Qualifier @Retention(AnnotationRetention.BINARY) annotation class MainDispatcher

/**
 * Hilt module that provides standard Coroutine Dispatchers. This is the central location where
 * global dispatchers are bound.
 */
@Module
@InstallIn(SingletonComponent::class)
internal object CoroutinesModule {

  @Provides
  @IoDispatcher
  @Suppress("GlobalCoroutineDispatchers", "AndroidLintDispatcherUsage")
  fun provideIoDispatcher(): CoroutineDispatcher = Dispatchers.IO

  @Provides
  @DefaultDispatcher
  @Suppress("GlobalCoroutineDispatchers", "AndroidLintDispatcherUsage")
  fun provideDefaultDispatcher(): CoroutineDispatcher = Dispatchers.Default

  @Provides
  @MainDispatcher
  @Suppress("GlobalCoroutineDispatchers", "AndroidLintDispatcherUsage")
  fun provideMainDispatcher(): CoroutineDispatcher = Dispatchers.Main
}
