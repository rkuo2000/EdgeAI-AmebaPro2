unset ANDROID_PREFS_ROOT && cd Android/src && ./gradlew assembleDebug --no-daemon -Dorg.gradle.workers.max=2 -Dorg.gradle.jvmargs="-XX:TieredStopAtLevel=1 -Xverify:none"
