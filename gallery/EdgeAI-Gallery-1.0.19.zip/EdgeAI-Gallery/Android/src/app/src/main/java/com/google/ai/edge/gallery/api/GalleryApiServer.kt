/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.api

import android.graphics.BitmapFactory
import android.util.Log
import com.google.ai.edge.gallery.ui.llmchat.LlmModelInstance
import com.google.ai.edge.litertlm.Content
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.Message
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** API mode releases the UI session and restores its history after all API work finishes. */
internal class GalleryApiServer(
  private val instance: LlmModelInstance,
  private val modelName: String,
  private val alias: String,
  private val token: String,
  private val supportImage: Boolean,
  private val supportAudio: Boolean,
  chatHistory: List<Message>,
  private val onStatus: (String) -> Unit,
) {
  private val running = AtomicBoolean(false)
  private val busy = AtomicBoolean(false)
  private val worker = Executors.newSingleThreadExecutor()
  private val timers = Executors.newSingleThreadScheduledExecutor()
  private var listener: ServerSocket? = null
  private var acceptThread: Thread? = null
  @Volatile private var client: Socket? = null
  @Volatile private var conversation: Conversation? = null

  private val chatSession = SuspendedChatSession(
    release = { instance.conversation.close() },
    restore = {
      instance.conversation = instance.engine.createConversation(
        instance.conversationConfig.copy(initialMessages = chatHistory)
      )
    },
  )

  fun start() {
    listener = ServerSocket(11434)
    chatSession.suspend()
    running.set(true)
    acceptThread = Thread({
      while (running.get()) {
        val socket = try { listener!!.accept() } catch (_: Exception) { break }
        if (!busy.compareAndSet(false, true)) {
          socket.use { runCatching { reply(it, 409, ChatCompletionProtocol.error("Model busy")) } }
          continue
        }
        client = socket
        worker.execute {
          socket.use {
            val timedOut = AtomicBoolean(false)
            var deadline = timers.schedule({ runCatching { socket.close() } }, 30, TimeUnit.SECONDS)
            try {
              socket.soTimeout = 15000
              val request = ChatCompletionProtocol.readRequest(socket.getInputStream().buffered(), token)
              deadline.cancel(false)
              if (request.model != alias && request.model != modelName) throw ApiError(404, "Use model $alias or $modelName")
              request.image?.let { image ->
                if (!supportImage) throw ApiError(400, "This model session does not support images; open Ask Image with a vision model")
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(image, 0, image.size, bounds)
                if (bounds.outWidth !in 1..4096 || bounds.outHeight !in 1..4096 || bounds.outWidth.toLong() * bounds.outHeight > 16_000_000) {
                  throw ApiError(400, "Invalid image or dimensions exceed 4096 / 16 megapixels")
                }
              }
              if (request.audio != null && !supportAudio) {
                throw ApiError(400, "This model session does not support audio; open AI Chat with an audio-capable model")
              }
              if (!running.get()) throw ApiError(503, "API stopped")
              onStatus(if (request.audio != null) "Recognizing audio…" else if (request.image != null) "Recognizing image…" else "Generating response…")
              val audio = request.audio?.let {
                if (request.audioFormat == "wav") it else ApiAudioDecoder.decode(it) { !running.get() }
              }
              if (!running.get()) throw ApiError(503, "API stopped")
              val active = instance.engine.createConversation(
                instance.conversationConfig.copy(
                  systemInstruction = null,
                  initialMessages = emptyList(),
                  tools = emptyList(),
                  extraContext = mapOf("enable_thinking" to false),
                )
              )
              conversation = active
              val result = try {
                deadline = timers.schedule({
                  timedOut.set(true)
                  runCatching { active.cancelProcess() }
                }, 180, TimeUnit.SECONDS)
                if (!running.get()) throw ApiError(503, "API stopped")
                val answer = active.sendMessage(
                  Contents.of(buildList {
                    request.image?.let { add(Content.ImageBytes(it)) }
                    audio?.let { add(Content.AudioBytes(it)) }
                    add(Content.Text(request.prompt))
                  }),
                  extraContext = mapOf("enable_thinking" to false),
                ).toString()
                if (timedOut.get()) throw ApiError(504, "Inference timed out")
                if (!running.get()) throw ApiError(503, "API stopped")
                answer
              } finally {
                deadline.cancel(false)
                try { active.close() } finally { conversation = null }
              }
              reply(socket, 200, ChatCompletionProtocol.completion(modelName, result))
              onStatus(result)
            } catch (e: Exception) {
              Log.e("GalleryApiServer", "API inference failed", e)
              val status = when {
                timedOut.get() -> 504
                e is ApiError -> e.status
                e is SocketTimeoutException -> 408
                else -> 500
              }
              val message = if (timedOut.get()) "Inference timed out" else if (e is ApiError) e.message else "Request failed: ${e.message ?: e.javaClass.simpleName}"
              runCatching { reply(socket, status, ChatCompletionProtocol.error(message)) }
              onStatus(message)
            } finally {
              deadline.cancel(false)
              client = null
              busy.set(false)
            }
          }
        }
      }
    }, "gallery-api-accept").also { it.start() }
  }

  /** Call on an IO thread; wait for native inference to release the engine before enabling chat. */
  fun close() {
    running.set(false)
    runCatching { listener?.close() }
    acceptThread?.join()
    runCatching { client?.close() }
    runCatching { conversation?.cancelProcess() }
    worker.shutdown()
    while (!worker.awaitTermination(1, TimeUnit.SECONDS)) {
      runCatching { conversation?.cancelProcess() }
    }
    timers.shutdownNow()
    chatSession.restore()
  }

  private fun reply(socket: Socket, status: Int, json: String) {
    val bytes = json.toByteArray(Charsets.UTF_8)
    val reason = if (status == 200) "OK" else "Error"
    val header = "HTTP/1.1 $status $reason\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n"
    socket.getOutputStream().apply {
      write(header.toByteArray(Charsets.US_ASCII))
      write(bytes)
      flush()
    }
  }
}
