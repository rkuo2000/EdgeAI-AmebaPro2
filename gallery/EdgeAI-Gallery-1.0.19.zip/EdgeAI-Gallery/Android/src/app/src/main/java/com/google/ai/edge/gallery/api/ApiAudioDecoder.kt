package com.google.ai.edge.gallery.api

import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaDataSource
import android.media.MediaExtractor
import android.media.MediaFormat
import android.os.SystemClock
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Decode the first audio track locally; never follow a client-supplied URL or write media to disk. */
internal object ApiAudioDecoder {
  fun decode(bytes: ByteArray, cancelled: () -> Boolean = { false }): ByteArray {
    val extractor = MediaExtractor()
    var codec: MediaCodec? = null
    val source = object : MediaDataSource() {
      override fun getSize() = bytes.size.toLong()
      override fun close() = Unit
      override fun readAt(position: Long, buffer: ByteArray, offset: Int, size: Int): Int {
        if (size == 0) return 0
        if (position < 0 || position >= bytes.size) return -1
        val count = minOf(size, bytes.size - position.toInt())
        bytes.copyInto(buffer, offset, position.toInt(), position.toInt() + count)
        return count
      }
    }
    try {
      val deadline = SystemClock.elapsedRealtime() + 30_000
      extractor.setDataSource(source)
      val track = (0 until extractor.trackCount).firstOrNull {
        extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
      } ?: throw ApiError(400, "Media contains no audio track")
      extractor.selectTrack(track)
      val format = extractor.getTrackFormat(track)
      format.setInteger(MediaFormat.KEY_PCM_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
      val decoder = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME)!!)
      codec = decoder
      decoder.configure(format, null, null, 0)
      decoder.start()
      val pcm = MonoPcmWav()
      val info = MediaCodec.BufferInfo()
      var inputEnded = false
      while (true) {
        if (cancelled()) throw ApiError(503, "API stopped")
        if (SystemClock.elapsedRealtime() >= deadline) throw ApiError(408, "Audio decoding timed out")
        if (!inputEnded) {
          val index = decoder.dequeueInputBuffer(10_000)
          if (index >= 0) {
            val input = decoder.getInputBuffer(index)!!
            input.clear()
            val size = extractor.readSampleData(input, 0)
            if (size < 0) {
              decoder.queueInputBuffer(index, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
              inputEnded = true
            } else {
              if (extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_ENCRYPTED != 0) {
                throw ApiError(400, "Encrypted audio is not supported")
              }
              decoder.queueInputBuffer(index, 0, size, extractor.sampleTime, 0)
              extractor.advance()
            }
          }
        }
        val index = decoder.dequeueOutputBuffer(info, 10_000)
        if (index >= 0) {
          try {
            if (info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
              val outputFormat = decoder.getOutputFormat(index)
              val encoding = if (outputFormat.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                outputFormat.getInteger(MediaFormat.KEY_PCM_ENCODING)
              } else AudioFormat.ENCODING_PCM_16BIT
              if (encoding != AudioFormat.ENCODING_PCM_16BIT) throw ApiError(400, "Decoder must produce 16-bit PCM audio")
              val output = decoder.getOutputBuffer(index)!!
              output.position(info.offset)
              output.limit(info.offset + info.size)
              pcm.append(output.slice().order(ByteOrder.LITTLE_ENDIAN),
                outputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE),
                outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
            }
          } finally {
            decoder.releaseOutputBuffer(index, false)
          }
          if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
        }
      }
      return pcm.finish()
    } catch (e: ApiError) {
      throw e
    } catch (e: Exception) {
      throw ApiError(400, "Cannot decode audio: invalid media or unsupported audio codec")
    } finally {
      try { codec?.release() } finally {
        try { extractor.release() } finally { source.close() }
      }
    }
  }
}

/** Bounded PCM accumulation and channel averaging, shared with host-side tests. */
internal class MonoPcmWav {
  private val data = ByteArrayOutputStream()
  private var sampleRate = 0

  fun append(buffer: ByteBuffer, rate: Int, channels: Int) {
    if (rate !in 8000..48000 || channels !in 1..8 || buffer.remaining() % (channels * 2) != 0) {
      throw ApiError(400, "Audio must decode to 8000–48000 Hz PCM with 1–8 channels")
    }
    if (sampleRate != 0 && sampleRate != rate) throw ApiError(400, "Audio sample rate changed during decoding")
    sampleRate = rate
    val frames = buffer.remaining() / (channels * 2)
    if (data.size().toLong() + frames * 2L > rate * 2L * 30) {
      throw ApiError(413, "MP3/MP4 audio must be at most 30 seconds")
    }
    buffer.order(ByteOrder.LITTLE_ENDIAN)
    repeat(frames) {
      var sum = 0
      repeat(channels) { sum += buffer.short.toInt() }
      val sample = sum / channels
      data.write(sample and 255)
      data.write((sample shr 8) and 255)
    }
  }

  fun finish(): ByteArray {
    if (data.size() == 0) throw ApiError(400, "Media contains no decoded audio samples")
    return ByteBuffer.allocate(44 + data.size()).order(ByteOrder.LITTLE_ENDIAN)
      .put("RIFF".toByteArray()).putInt(36 + data.size()).put("WAVEfmt ".toByteArray())
      .putInt(16).putShort(1).putShort(1).putInt(sampleRate).putInt(sampleRate * 2)
      .putShort(2).putShort(16).put("data".toByteArray()).putInt(data.size())
      .put(data.toByteArray()).array()
  }
}
