/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.data

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.edit
import androidx.core.net.toUri
import androidx.core.os.bundleOf
import androidx.lifecycle.Observer
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.google.ai.edge.gallery.AppLifecycleProvider
import com.google.ai.edge.gallery.GalleryEvent
import com.google.ai.edge.gallery.R
import com.google.ai.edge.gallery.firebaseAnalytics
import com.google.ai.edge.gallery.worker.DownloadWorker
import java.util.UUID
import java.util.concurrent.Executors

private const val TAG = "AGDownloadRepository"
private const val MODEL_NAME_TAG = "modelName"
private const val TASK_ID_TAG = "taskId"

data class AGWorkInfo(val taskId: String, val modelName: String, val workId: String)

interface DownloadRepository {
  fun downloadModel(
    task: Task?,
    model: Model,
    includeExtraDataFiles: Boolean = true,
    onStatusUpdated: (model: Model, status: ModelDownloadStatus) -> Unit,
  )

  fun cancelDownloadModel(model: Model)

  fun cancelAll(onComplete: () -> Unit)

  fun observerWorkerProgress(
    workerId: UUID,
    task: Task?,
    model: Model,
    onStatusUpdated: (model: Model, status: ModelDownloadStatus) -> Unit,
  )

  fun downloadExtraDataFiles(
    task: Task?,
    model: Model,
    onStatusUpdated: (model: Model, status: ModelDownloadStatus) -> Unit,
  )

  fun cancelDownloadExtraDataFiles(model: Model)
}

private const val EXTRA_DATA_SUFFIX = "_extra_data"

private const val DOWNLOAD_FROM_GLOBAL_MODEL_MANAGER_TASK_ID = "___"

/**
 * Repository for managing model downloads using WorkManager.
 *
 * This class provides methods to initiate model downloads, cancel downloads, observe download
 * progress, and retrieve information about enqueued or running download tasks. It utilizes
 * WorkManager to handle background download operations.
 */
class DefaultDownloadRepository(
  private val context: Context,
  private val lifecycleProvider: AppLifecycleProvider,
) : DownloadRepository {
  private val workManager = WorkManager.getInstance(context)
  /**
   * Stores the start time of a model download.
   *
   * We use SharedPreferences to persist the download start times. This ensures that the data is
   * still available after the app restarts. The key is the model name and the value is the download
   * start time in milliseconds.
   */
  private val downloadStartTimeSharedPreferences =
    context.getSharedPreferences("download_start_time_ms", Context.MODE_PRIVATE)

  override fun downloadModel(
    task: Task?,
    model: Model,
    includeExtraDataFiles: Boolean,
    onStatusUpdated: (model: Model, status: ModelDownloadStatus) -> Unit,
  ) {
    // Create input data.
    val builder = Data.Builder()
    val extraFiles =
      if (includeExtraDataFiles) model.downloadInfo.extraDataFiles(task?.id) else emptyList()
    val totalBytes = model.downloadInfo.sizeInBytes + extraFiles.sumOf { it.sizeInBytes }
    val inputDataBuilder =
      builder
        .putString(KEY_MODEL_NAME, model.name)
        .putString(KEY_MODEL_URL, model.downloadInfo.url)
        .putString(KEY_MODEL_COMMIT_HASH, model.downloadInfo.version)
        .putString(
          KEY_MODEL_DOWNLOAD_MODEL_DIR,
          if (model.downloadInfo.imported) IMPORTS_DIR else model.normalizedName,
        )
        .putString(KEY_MODEL_DOWNLOAD_FILE_NAME, model.downloadInfo.downloadFileName)
        .putBoolean(KEY_MODEL_IS_ZIP, model.downloadInfo.isZip)
        .putString(KEY_MODEL_UNZIPPED_DIR, model.downloadInfo.unzipDir)
        .putLong(KEY_MODEL_TOTAL_BYTES, totalBytes)
        .putBoolean(KEY_MODEL_IS_IMPORTED, model.downloadInfo.imported)

    if (extraFiles.isNotEmpty()) {
      inputDataBuilder
        .putString(KEY_MODEL_EXTRA_DATA_URLS, extraFiles.joinToString(",") { it.url })
        .putString(
          KEY_MODEL_EXTRA_DATA_DOWNLOAD_FILE_NAMES,
          extraFiles.joinToString(",") { it.downloadFileName },
        )
    }
    if (model.downloadInfo.accessToken != null) {
      inputDataBuilder.putString(KEY_MODEL_DOWNLOAD_ACCESS_TOKEN, model.downloadInfo.accessToken)
    }
    val inputData = inputDataBuilder.build()

    // Create worker request.
    val downloadWorkRequest =
      OneTimeWorkRequestBuilder<DownloadWorker>()
        .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
        .setInputData(inputData)
        .addTag("$MODEL_NAME_TAG:${model.name}")
        .addTag("$TASK_ID_TAG:${task?.id ?: ""}")
        .build()

    val workerId = downloadWorkRequest.id

    // Start!
    workManager.enqueueUniqueWork(model.name, ExistingWorkPolicy.REPLACE, downloadWorkRequest)

    // Observe progress.
    observerWorkerProgress(
      workerId = workerId,
      task = task,
      model = model,
      onStatusUpdated = onStatusUpdated,
      isExtraDataOnly = false,
      expectedTotalBytes = totalBytes,
    )
  }

  override fun downloadExtraDataFiles(
    task: Task?,
    model: Model,
    onStatusUpdated: (model: Model, status: ModelDownloadStatus) -> Unit,
  ) {
    val extraFiles = model.downloadInfo.extraDataFiles(task?.id)
    if (extraFiles.isEmpty()) return
    val totalBytes = extraFiles.sumOf { it.sizeInBytes }

    val inputData =
      Data.Builder()
        .putString(KEY_MODEL_NAME, model.name)
        .putString(KEY_MODEL_COMMIT_HASH, model.downloadInfo.version)
        .putString(
          KEY_MODEL_DOWNLOAD_MODEL_DIR,
          if (model.downloadInfo.imported) IMPORTS_DIR else model.normalizedName,
        )
        .putLong(KEY_MODEL_TOTAL_BYTES, totalBytes)
        .putBoolean(KEY_MODEL_IS_IMPORTED, model.downloadInfo.imported)
        .putBoolean(KEY_MODEL_EXTRA_DATA_ONLY, true)
        .putString(KEY_MODEL_EXTRA_DATA_URLS, extraFiles.joinToString(",") { it.url })
        .putString(
          KEY_MODEL_EXTRA_DATA_DOWNLOAD_FILE_NAMES,
          extraFiles.joinToString(",") { it.downloadFileName },
        )
        .apply {
          if (model.downloadInfo.accessToken != null) {
            putString(KEY_MODEL_DOWNLOAD_ACCESS_TOKEN, model.downloadInfo.accessToken)
          }
        }
        .build()

    val downloadWorkRequest =
      OneTimeWorkRequestBuilder<DownloadWorker>()
        .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
        .setInputData(inputData)
        .addTag("$MODEL_NAME_TAG:${model.name}$EXTRA_DATA_SUFFIX")
        .addTag("$TASK_ID_TAG:${task?.id ?: ""}")
        .build()

    val workerId = downloadWorkRequest.id
    workManager.enqueueUniqueWork(
      "${model.name}$EXTRA_DATA_SUFFIX",
      ExistingWorkPolicy.REPLACE,
      downloadWorkRequest,
    )

    observerWorkerProgress(
      workerId = workerId,
      task = task,
      model = model,
      onStatusUpdated = onStatusUpdated,
      isExtraDataOnly = true,
      expectedTotalBytes = totalBytes,
    )
  }

  override fun cancelDownloadExtraDataFiles(model: Model) {
    workManager.cancelAllWorkByTag("$MODEL_NAME_TAG:${model.name}$EXTRA_DATA_SUFFIX")
  }

  override fun cancelDownloadModel(model: Model) {
    workManager.cancelAllWorkByTag("$MODEL_NAME_TAG:${model.name}")
    workManager.cancelAllWorkByTag("$MODEL_NAME_TAG:${model.name}$EXTRA_DATA_SUFFIX")
  }

  override fun cancelAll(onComplete: () -> Unit) {
    workManager
      .cancelAllWork()
      .result
      .addListener({ onComplete() }, Executors.newSingleThreadExecutor())
  }

  override fun observerWorkerProgress(
    workerId: UUID,
    task: Task?,
    model: Model,
    onStatusUpdated: (model: Model, status: ModelDownloadStatus) -> Unit,
  ) {
    observerWorkerProgress(
      workerId = workerId,
      task = task,
      model = model,
      onStatusUpdated = onStatusUpdated,
      isExtraDataOnly = false,
      expectedTotalBytes = 0L,
    )
  }

  private fun observerWorkerProgress(
    workerId: UUID,
    task: Task?,
    model: Model,
    onStatusUpdated: (model: Model, status: ModelDownloadStatus) -> Unit,
    isExtraDataOnly: Boolean,
    expectedTotalBytes: Long = 0L,
  ) {
    val liveData = workManager.getWorkInfoByIdLiveData(workerId)
    val observer =
      object : Observer<WorkInfo?> {
        override fun onChanged(workInfo: WorkInfo?) {
          if (workInfo != null) {
            when (workInfo.state) {
              WorkInfo.State.ENQUEUED -> {
                downloadStartTimeSharedPreferences.edit {
                  putLong(model.name, System.currentTimeMillis())
                }
                firebaseAnalytics?.logEvent(
                  GalleryEvent.MODEL_DOWNLOAD.id,
                  bundleOf("event_type" to "start", "model_id" to model.name),
                )
              }

              WorkInfo.State.RUNNING -> {
                val receivedBytes = workInfo.progress.getLong(KEY_MODEL_DOWNLOAD_RECEIVED_BYTES, 0L)
                val downloadRate = workInfo.progress.getLong(KEY_MODEL_DOWNLOAD_RATE, 0L)
                val remainingSeconds =
                  workInfo.progress.getLong(KEY_MODEL_DOWNLOAD_REMAINING_MS, 0L)
                val startUnzipping = workInfo.progress.getBoolean(KEY_MODEL_START_UNZIPPING, false)

                if (!startUnzipping) {
                  if (receivedBytes != 0L) {
                    val totalBytes =
                      if (expectedTotalBytes > 0L) expectedTotalBytes
                      else if (isExtraDataOnly)
                        model.downloadInfo.extraDataFiles(task?.id).sumOf { it.sizeInBytes }
                      else model.downloadInfo.totalBytes
                    onStatusUpdated(
                      model,
                      ModelDownloadStatus(
                        status = ModelDownloadStatusType.IN_PROGRESS,
                        totalBytes = totalBytes,
                        receivedBytes = receivedBytes,
                        bytesPerSecond = downloadRate,
                        remainingMs = remainingSeconds,
                      ),
                    )
                  }
                } else {
                  onStatusUpdated(
                    model,
                    ModelDownloadStatus(status = ModelDownloadStatusType.UNZIPPING),
                  )
                }
              }

              WorkInfo.State.SUCCEEDED -> {
                liveData.removeObserver(this)
                Log.d("repo", "worker $workerId success")
                onStatusUpdated(
                  model,
                  ModelDownloadStatus(status = ModelDownloadStatusType.SUCCEEDED),
                )
                if (isExtraDataOnly) {
                  sendNotification(
                    title =
                      context.getString(R.string.download_extra_data_notification_title_success),
                    text =
                      context
                        .getString(R.string.download_extra_data_notification_content_success)
                        .format(
                          model.downloadInfo.optionalComponentsLabel(context, task?.id).ifEmpty {
                            model.name
                          }
                        ),
                    taskId = task?.id ?: DOWNLOAD_FROM_GLOBAL_MODEL_MANAGER_TASK_ID,
                    modelName = model.name,
                  )
                } else {
                  sendNotification(
                    title = context.getString(R.string.notification_title_success),
                    text =
                      context.getString(R.string.notification_content_success).format(model.name),
                    taskId = task?.id ?: DOWNLOAD_FROM_GLOBAL_MODEL_MANAGER_TASK_ID,
                    modelName = model.name,
                  )
                }

                val startTime = downloadStartTimeSharedPreferences.getLong(model.name, 0L)
                val duration = System.currentTimeMillis() - startTime
                firebaseAnalytics?.logEvent(
                  GalleryEvent.MODEL_DOWNLOAD.id,
                  bundleOf(
                    "event_type" to "success",
                    "model_id" to model.name,
                    "duration_ms" to duration,
                  ),
                )
                downloadStartTimeSharedPreferences.edit { remove(model.name) }
              }

              WorkInfo.State.FAILED,
              WorkInfo.State.CANCELLED -> {
                liveData.removeObserver(this)
                var status = ModelDownloadStatusType.FAILED
                val errorMessage =
                  workInfo.outputData.getString(KEY_MODEL_DOWNLOAD_ERROR_MESSAGE) ?: ""
                Log.d("repo", "worker $workerId FAILED or CANCELLED: $errorMessage")
                if (workInfo.state == WorkInfo.State.CANCELLED) {
                  status = ModelDownloadStatusType.NOT_DOWNLOADED
                } else {
                  if (isExtraDataOnly) {
                    sendNotification(
                      title =
                        context.getString(R.string.download_extra_data_notification_title_fail),
                      text =
                        context
                          .getString(R.string.download_extra_data_notification_content_fail)
                          .format(
                            model.downloadInfo.optionalComponentsLabel(context, task?.id).ifEmpty {
                              model.name
                            }
                          ),
                      taskId = "",
                      modelName = "",
                    )
                  } else {
                    sendNotification(
                      title = context.getString(R.string.notification_title_fail),
                      text =
                        context.getString(R.string.notification_content_fail).format(model.name),
                      taskId = "",
                      modelName = "",
                    )
                  }
                }
                onStatusUpdated(
                  model,
                  ModelDownloadStatus(status = status, errorMessage = errorMessage),
                )

                val startTime = downloadStartTimeSharedPreferences.getLong(model.name, 0L)
                val duration = System.currentTimeMillis() - startTime
                firebaseAnalytics?.logEvent(
                  GalleryEvent.MODEL_DOWNLOAD.id,
                  bundleOf(
                    "event_type" to "failure",
                    "model_id" to model.name,
                    "duration_ms" to duration,
                  ),
                )
                downloadStartTimeSharedPreferences.edit { remove(model.name) }
              }

              else -> {}
            }
          }
        }
      }

    if (Looper.myLooper() == Looper.getMainLooper()) {
      liveData.observeForever(observer)
    } else {
      Handler(Looper.getMainLooper()).post { liveData.observeForever(observer) }
    }
  }

  @SuppressLint("PendingIntentMutability")
  private fun sendNotification(title: String, text: String, taskId: String, modelName: String) {
    // Don't send notification if app is in foreground.
    if (lifecycleProvider.isAppInForeground) {
      return
    }

    val channelId = "download_notification"
    val channelName = "AI Edge Gallery download notification"

    // Create the NotificationChannel, but only on API 26+ because
    // the NotificationChannel class is new and not in the support library
    val importance = NotificationManager.IMPORTANCE_HIGH
    val channel = NotificationChannel(channelId, channelName, importance)
    val notificationManager: NotificationManager =
      context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    notificationManager.createNotificationChannel(channel)

    val intent: Intent
    if (taskId.isEmpty()) {
      // If taskId is empty, it's a failed download. Just open the app's main screen.
      intent = context.packageManager.getLaunchIntentForPackage(context.packageName)!!
    }
    // Download from global model manager. Open the global model manager screen.
    else if (taskId == DOWNLOAD_FROM_GLOBAL_MODEL_MANAGER_TASK_ID) {
      intent =
        Intent(Intent.ACTION_VIEW, "com.google.ai.edge.gallery://global_model_manager".toUri())
          .apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
    } else {

      // Otherwise, create the deep link as before.
      intent =
        Intent(
            Intent.ACTION_VIEW,
            "com.google.ai.edge.gallery://model/$taskId/${modelName}".toUri(),
          )
          .apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
    }

    // Create a PendingIntent
    val pendingIntent: PendingIntent =
      PendingIntent.getActivity(
        context,
        0,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )

    val builder =
      NotificationCompat.Builder(context, channelId)
        // TODO: replace icon.
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle(title)
        .setContentText(text)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setContentIntent(pendingIntent)
        .setAutoCancel(true)

    with(NotificationManagerCompat.from(context)) {
      // notificationId is a unique int for each notification that you must define
      if (
        ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
          PackageManager.PERMISSION_GRANTED
      ) {
        // Permission not granted, return or handle accordingly. In real app, request permission.
        return
      }
      val notificationId =
        (modelName.hashCode() xor taskId.hashCode()).let { if (it == 0) 1 else it }
      notify(notificationId, builder.build())
    }
  }
}
