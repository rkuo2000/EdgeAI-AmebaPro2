/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.api

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.io.InputStream
import java.util.Base64
import java.util.UUID

internal class ApiError(val status: Int, override val message: String) : Exception(message)
internal data class ChatPrompt(val model: String, val prompt: String, val image: ByteArray?, val audio: ByteArray? = null, val audioFormat: String = "wav")

/** Deliberately small OpenAI-compatible subset for text, image, and audio clients. */
internal object ChatCompletionProtocol {
  const val MAX_BODY = 6 * 1024 * 1024

  fun readRequest(input: InputStream, token: String): ChatPrompt {
    var headerBytes = 0
    fun line(): String {
      val bytes = ArrayList<Byte>()
      while (true) {
        val b = input.read()
        if (b < 0) throw ApiError(400, "Incomplete HTTP request")
        if (++headerBytes > 16384) throw ApiError(431, "Headers too large")
        if (b == 10) break
        bytes.add(b.toByte())
      }
      return bytes.toByteArray().toString(Charsets.US_ASCII).removeSuffix("\r")
    }
    val request = line().split(' ')
    if (request.size != 3) throw ApiError(400, "Invalid request line")
    if (request[1] != "/v1/chat/completions") throw ApiError(404, "Unknown endpoint")
    if (request[0] != "POST") throw ApiError(405, "Use POST")
    val headers = mutableMapOf<String, String>()
    while (true) {
      val value = line()
      if (value.isEmpty()) break
      val colon = value.indexOf(':')
      if (colon <= 0) throw ApiError(400, "Invalid header")
      val key = value.substring(0, colon).lowercase(java.util.Locale.ROOT)
      if (headers.put(key, value.substring(colon + 1).trim()) != null) {
        throw ApiError(400, "Duplicate header")
      }
    }
    if (headers["authorization"] != "Bearer $token") throw ApiError(401, "Invalid API key")
    if (headers.containsKey("transfer-encoding")) throw ApiError(400, "Use Content-Length")
    if (headers["content-type"]?.substringBefore(';')?.trim() != "application/json") {
      throw ApiError(415, "Use application/json")
    }
    val length = headers["content-length"]?.toIntOrNull() ?: throw ApiError(411, "Content-Length required")
    if (length !in 1..MAX_BODY) throw ApiError(413, "Request too large or empty")
    val body = ByteArray(length)
    var offset = 0
    while (offset < length) {
      val count = input.read(body, offset, length - offset)
      if (count < 0) throw ApiError(400, "Incomplete body")
      offset += count
    }
    return parse(body.toString(Charsets.UTF_8))
  }

  fun parse(body: String): ChatPrompt {
    try {
      val root = JsonParser.parseString(body).asJsonObject
      if (root.has("stream") && root["stream"].asBoolean) throw ApiError(400, "Streaming is not supported; use stream:false")
      val supported = setOf("model", "messages", "stream")
      if (root.keySet().any { it !in supported }) throw ApiError(400, "Supported fields: model, messages, stream")
      val model = root["model"].asString
      val messages = root["messages"].asJsonArray
      if (messages.size() != 1 || messages[0].asJsonObject["role"].asString != "user") {
        throw ApiError(400, "Send exactly one user message per request")
      }
      val content = messages[0].asJsonObject["content"]
      val parts = if (content.isJsonPrimitive && content.asJsonPrimitive.isString) {
        JsonArray().apply { add(JsonObject().apply {
          addProperty("type", "text")
          addProperty("text", content.asString)
        }) }
      } else content.asJsonArray
      val texts = mutableListOf<String>()
      var image: ByteArray? = null
      var audio: ByteArray? = null
      var audioFormat = "wav"
      for (part in parts) {
        val item = part.asJsonObject
        when (item["type"].asString) {
          "text" -> texts.add(item["text"].asString)
          "image_url" -> {
            if (image != null) throw ApiError(400, "Send one image only")
            val url = item["image_url"].asJsonObject["url"].asString
            val prefix = url.substringBefore(',')
            if (prefix !in setOf("data:image/jpeg;base64", "data:image/png;base64")) {
              throw ApiError(400, "Use a JPEG or PNG base64 data URL")
            }
            image = Base64.getDecoder().decode(url.substringAfter(',', ""))
            val isJpeg = image.size >= 3 && image[0] == 0xff.toByte() &&
              image[1] == 0xd8.toByte() && image[2] == 0xff.toByte()
            val pngSignature = byteArrayOf(-119, 80, 78, 71, 13, 10, 26, 10)
            val isPng = image.size >= 8 && image.copyOfRange(0, 8).contentEquals(pngSignature)
            if (!isJpeg && !isPng) throw ApiError(400, "Invalid JPEG or PNG")
          }
          "input_audio" -> {
            if (audio != null) throw ApiError(400, "Send one audio clip only")
            val input = item["input_audio"].asJsonObject
            audioFormat = input["format"].asString
            if (audioFormat !in setOf("wav", "mp3", "mp4")) throw ApiError(400, "Use WAV, MP3, or MP4 audio (format:wav/mp3/mp4)")
            audio = Base64.getDecoder().decode(input["data"].asString)
            if (audio.isEmpty()) throw ApiError(400, "Audio must not be empty")
            if (audioFormat == "wav") validateWav(audio)
          }
          else -> throw ApiError(400, "Unsupported content type")
        }
      }
      val prompt = texts.joinToString("\n")
      if (prompt.isBlank() || prompt.length > 8192) throw ApiError(400, "Prompt must contain 1–8192 characters")
      return ChatPrompt(model, prompt, image, audio, audioFormat)
    } catch (e: ApiError) {
      throw e
    } catch (e: Exception) {
      throw ApiError(400, "Malformed JSON or media data")
    }
  }

  /** Validate chunk boundaries and PCM metadata before passing untrusted bytes to the runtime. */
  private fun validateWav(bytes: ByteArray) {
    fun invalid(): Nothing = throw ApiError(400, "Use a nonempty mono 16-bit PCM WAV (8000–48000 Hz)")
    fun tag(offset: Int) = String(bytes, offset, 4, Charsets.US_ASCII)
    fun uint(offset: Int, count: Int): Long = (0 until count).fold(0L) { value, i ->
      value or ((bytes[offset + i].toLong() and 255) shl (8 * i))
    }
    if (bytes.size < 12 || tag(0) != "RIFF" || tag(8) != "WAVE" ||
      uint(4, 4) != bytes.size.toLong() - 8) invalid()
    var offset = 12
    var hasFormat = false
    var hasData = false
    while (offset < bytes.size) {
      if (bytes.size - offset < 8) invalid()
      val id = tag(offset)
      val size = uint(offset + 4, 4)
      val start = offset + 8
      val end = start.toLong() + size
      val paddedEnd = end + size % 2
      if (paddedEnd > bytes.size) invalid()
      when (id) {
        "fmt " -> {
          if (hasFormat || size < 16) invalid()
          val rate = uint(start + 4, 4)
          if (uint(start, 2) != 1L || uint(start + 2, 2) != 1L ||
            rate !in 8000L..48000L || uint(start + 8, 4) != rate * 2 ||
            uint(start + 12, 2) != 2L || uint(start + 14, 2) != 16L) invalid()
          hasFormat = true
        }
        "data" -> {
          if (!hasFormat || hasData || size == 0L || size % 2 != 0L) invalid()
          hasData = true
        }
      }
      offset = paddedEnd.toInt()
    }
    if (!hasFormat || !hasData) invalid()
  }

  fun completion(model: String, answer: String): String = JsonObject().apply {
    addProperty("id", "chatcmpl-${UUID.randomUUID()}")
    addProperty("object", "chat.completion")
    addProperty("created", System.currentTimeMillis() / 1000)
    addProperty("model", model)
    add("choices", JsonArray().apply {
      add(JsonObject().apply {
        addProperty("index", 0)
        add("message", JsonObject().apply {
          addProperty("role", "assistant")
          addProperty("content", answer)
        })
        addProperty("finish_reason", "stop")
      })
    })
  }.toString()

  fun error(message: String): String = JsonObject().apply {
    add("error", JsonObject().apply { addProperty("message", message) })
  }.toString()
}
